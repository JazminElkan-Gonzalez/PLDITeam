Ariana Chae (ariana.chae@students.olin.edu)
Jazmin Gonzalez-Rivero (jazmin.gonzalez-rivero@students.olin.edu)
Caitlin Riley (caitlin.riley@students.olin.edu)

Progamming Language Implementation and Design
Olin College of Engineering, Spring 2014
Assignment 5

Note:

We discovered a good way to figure out which token the error is occuring on. Just do:
// of NONE => parseError (stringOfToken (hd ts)) //